/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Paintball.cpp
 * Author: luke craig
 * Purpose: game pidgeon paintball
 *
 * Created on February 1, 2020, 11:06 PM
 */

#include <iostream>
#include <iomanip>
#include <string>

//Add in players name and implement inside last output


using namespace std;

int randomPlayerHide();
int randomPlayerShoot();
void shootAt();
void spotHide();

int main() {
    char shoot, hide; //Player choice 
    char shootR, hideR; //computer choice
    char pA; //play again in 'y' or 'n'
    bool playAgain = true;
    int life = 3, lifeR = 3, numRoundsPlayed = 0, wins = 0; //3 lives each
    
    string playerName;
    
    
    cout<<"Welcome to GamePidegon's Paintball!\n"
            <<"In this game you will be playing against a computer "
            << "and trying to hit him with a paintball."
            <<"\nHowever, be warned, both you and the computer may move every turn!\n"
            <<"You have three lives, the computer has three lives, good luck!\n";
    cout<<"Player, enter your name: "<<endl; getline(cin, playerName); //pulls whole string in cin as 1 input
    while(playAgain){
        
        numRoundsPlayed++;
    do{
    shootAt(); cin>>shoot; //player
    spotHide(); cin>>hide;
    
    hideR = randomPlayerHide(); //computer
    shootR = randomPlayerShoot();
    cout<<endl;
    
    if(shoot==hideR){ //Your shot comes first
        cout<<"You hit the computer!";
        lifeR-=1;
    } //player shot
    else if(shoot!=hideR){
        cout<<"You missed!";
    }
    
    if(shootR==hide){ //Computer's turn
        cout<<"The computer hit you!";
        life-=1;
    } //computer shot
    else if(shootR!=hide){
        cout<<"Computer missed!";
    }
    cout<<"\nComputer Lives: "<<lifeR<<endl;
    cout<<"Your Lives: "<<life<<endl<<endl;
    } while((life>0) && (lifeR>0));
    
    for(int i = 0; i<10;i++) //provides space to see when you win or lose
        cout<<"\n";
    
    if(life==0){
        cout<<"You lost to the computer? Come on!\n";
        
    } //you lost
    else if(lifeR==0){
        cout<<"Good job "<<playerName<<"! You beat a flimsy computer program!\n";
        wins++;
    } //you won
    
    
    cout<<"Would you like to play again?\n'y' for yes\n'n' for no\n"<<endl; 
    cin>>pA;
    float winPercent = (float(wins)/float(numRoundsPlayed))*100.00;
    if(pA=='n'){
        cout<<"\nThanks for playing "<<playerName<<"!\n";
        std::cout<<std::setprecision(2)<<fixed<<"Your win percentage: %"<< winPercent;
        playAgain = false;
    }
    else{
        playAgain = true;
    }
    life = 3, lifeR = 3;
    }
}
int randomPlayerHide(){
    char hideR;
    int hiddenAt = rand()%3 + 1;
    if(hiddenAt==1)
        hide = 'l';
    else if(hiddenAt==2)
        hide = 'm';
    else
        hide = 'r';
    return hideR;
}
int randomPlayerShoot(){
    char shootR;
    int shootAt = rand()%3 + 1;
    if(shootAt==1)
        shoot = 'l';
    else if(shootAt==2)
        shoot = 'm';
    else
        shoot = 'r';
    return shootR;
}
void shootAt(){
    cout<<"What spot would you like to shoot at?\n'l' for left\n'm' for middle\n'r' for right"<<endl;
}
void spotHide(){
    cout<<"What spot would you like to move to?\n'l' for left\n'm' for middle\n'r' for right"<<endl;
}